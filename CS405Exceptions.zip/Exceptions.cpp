// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


//Steven mathias
//Assignment 4-1
//CS 405

#include <iostream>
#include <stdexcept> //Use this to allow for exceptions using "throw"


//Create custom exception from std::exception
struct CustomException : public std::exception {
    const char* what() const noexcept override
    {
        return "Custom exception occured";
    }
};



bool do_even_more_custom_application_logic()
{
    //DONE
    // TODO: Throw any standard exception
    throw std::runtime_error("Standard exception");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    //DONE
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try {

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    //acception handler to catch std::exception
    catch (const std::exception& e)
    {
        std::cout << "Catching exception" << e.what() << std::endl;
    }

    //DONE
    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    //DONE
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    if (den == 0) //If the denominator is equal to zero, throw exception as cannot divide by zero
    {
        throw std::runtime_error("Cannot divide by zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    //DONE
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try {

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //Only catch the runtime_error for the divide function and display error
    catch (const std::runtime_error& e)
    {
        std::cout << "Caught exception: " << e.what() << std::endl;
    }
}



int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    //DONE
    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    try {  //Wrap main function

        do_division();
        do_custom_application_logic();

    }

    catch (const CustomException& e) //catch custom exception and display message
    {
        std::cout << "Caught custom exception: " << e.what() << std::endl;
    }

    catch (const std::exception& e) //catch standard exception
    {
        std::cout << "Caught standard exception: " << e.what() << std::endl;
    }

    catch (...)
    {
        std::cout << "Caught unknown exception" << std::endl; //Prevent uncaught exception
    }

    return 0;

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu